# Kadiwa Mart Sales Forecasting (Python)

This folder contains a **simple, flat Python module** and **one main Jupyter notebook** to train and evaluate a sales forecasting model for Kadiwa Mart stores in Calapan.

## Project structure

- `kadiwa_sales_core.py` – core module with:
  - `TrainingConfig`
  - `SalesForecaster` (train + predict)
  - `load_series` / `load_store_series` (CSV helpers)
  - `save_model` / `load_model`
- `kadiwa_sales_forecasting.ipynb` – notebook to **generate sample Kadiwa data**, train per-store models, show accuracy, and test forecasts
- `requirements.txt` – Python and Jupyter dependencies

## Virtual environment (Windows)

From this folder in VS Code:

```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt jupyter ipykernel
```

Then select the `.venv` interpreter / kernel in VS Code.

## Accuracy / performance

When you run the training cell in the notebook, it prints:

- `Test R^2 score: <value>`
- `Approx forecast accuracy: <value>%`

and a short message describing whether it:

- meets the **80%+ accuracy** target,
- is between **75–80%**, or
- is **below 75%** (suggesting more data or tuning).

## Using the trained model in your backend

Example (per-store model):

```python
from kadiwa_sales_core import load_model

store_id = "CALSEDECO"  # other options: "PAPANDUNGIN", "JUBILEE"
model_path = f"models/sales_forecaster_store_{store_id}.joblib"

model = load_model(model_path)

# recent_sales: list or array of the most recent daily sales values for that store
forecast = model.predict_next(recent_sales, horizon=7)
```

This ML code is a **module** that your e-commerce system imports; the notebook is only for training and evaluation.
