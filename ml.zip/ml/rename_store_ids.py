from pathlib import Path

import pandas as pd

MAPPING = {
    "KADIWA_CALAPAN_1": "CALSEDECO",
    "KADIWA_CALAPAN_2": "PAPANDUNGIN",
    "KADIWA_CALAPAN_3": "JUBILEE",
}

CSV_PATHS = [
    Path("dataset/Train/kadiwa_sample_sales.csv"),
    Path("dataset/Validation/kadiwa_sample_sales.csv"),
]


def update_csv(path: Path) -> None:
    if not path.exists():
        print(f"Skipping {path}, file does not exist")
        return

    df = pd.read_csv(path)
    if "store_id" not in df.columns:
        print(f"Skipping {path}, no 'store_id' column found")
        return

    before = df["store_id"].unique()
    df["store_id"] = df["store_id"].replace(MAPPING)
    df.to_csv(path, index=False)
    after = df["store_id"].unique()
    print(f"Updated {path}: {before} -> {after}")


def main() -> None:
    for path in CSV_PATHS:
        update_csv(path)


if __name__ == "__main__":
    main()
